package com.udacity.DogServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogServerApplication.class, args);
	}

}
