package com.udacity.DogServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
