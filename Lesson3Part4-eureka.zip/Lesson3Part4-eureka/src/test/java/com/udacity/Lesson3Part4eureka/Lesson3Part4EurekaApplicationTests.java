package com.udacity.Lesson3Part4eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson3Part4EurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
