package com.udacity.Lesson3Part4eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson3Part4EurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson3Part4EurekaApplication.class, args);
	}

}
