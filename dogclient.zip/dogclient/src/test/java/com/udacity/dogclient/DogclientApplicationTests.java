package com.udacity.dogclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
